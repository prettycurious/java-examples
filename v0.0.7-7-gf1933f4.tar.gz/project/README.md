# 更新日志

### 2020年10月20日
1. 添加Fastjson 1.2.74
2. 新增EasyExcel WriteTest Demo
3. 新增EasyExcel 填充Excel Demo

### 2020年09月22日
1. 初始化项目
2. 添加自定义banner
3. 添加.gitignore
4. 添加README.md
5. 添加时间测试类
6. 添加一个接口存在多个实现类，动态调用不同的实现类
7. 添加MyBatis Plus Quick Start
8. 添加Git Tag

