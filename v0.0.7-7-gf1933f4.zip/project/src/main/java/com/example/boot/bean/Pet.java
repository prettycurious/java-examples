package com.example.boot.bean;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 *
 * @author tianwenyuan
 * Date: 2021/1/21
 * Time: 3:31 下午
 */
@Data
public class Pet {

    private String name;
    private Integer age;

}
