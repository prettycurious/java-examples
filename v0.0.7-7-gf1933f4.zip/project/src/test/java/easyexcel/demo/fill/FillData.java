package easyexcel.demo.fill;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 *
 * @author tianwenyuan
 * Date: 2020/10/20
 * Time: 5:23 下午
 */
@Data
public class FillData {
    private String name;
    private double number;
}