package interfaceTest.controller;

import interfaceTest.model.TestType;
import interfaceTest.service.TestService;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 *
 * @author tianwenyuan
 * Date: 2020/9/11
 * Time: 2:43 下午
 */
public class TestController {

    @Test
    public void main() {
//        TestEnum1 testEnum = new TestEnum1();
//        testEnum.setType(TestType.A);
//        TestService testService = (TestService) Class.forName(path).newInstance();
//        TestService t1 = testFactory.get(testEnum);
//        System.out.println(t1.firstStep());
//        System.out.println(t1.secondStep());
//        System.out.println(t1.thirdStep());
//        System.out.println("-----------");
//        testEnum.setType(TestType.B);
//        TestService t2 = testFactory.get(testEnum);
//        System.out.println(t2.firstStep());
//        System.out.println(t2.secondStep());
//        System.out.println(t2.thirdStep());
    }


}
