package interfaceTest.service;

/**
 * Created with IntelliJ IDEA.
 *
 * @author tianwenyuan
 * Date: 2020/9/11
 * Time: 2:38 下午
 */
public interface TestService {

    String firstStep();

    String secondStep();

    String thirdStep();
}
